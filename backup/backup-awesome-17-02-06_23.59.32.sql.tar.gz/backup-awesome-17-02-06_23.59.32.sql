-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: awesome
-- ------------------------------------------------------
-- Server version	5.7.17-0ubuntu0.16.04.1
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('0014863550293324b207fb6250146e48181c0e2352d3477000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355029.33239);
INSERT INTO `blogs` VALUES ('001486355064201d009c70794664e12a86d8d0ab6042688000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355064.20159);
INSERT INTO `blogs` VALUES ('001486355071043b25a6c8d39834ca3abd05b73351ec388000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355071.04376);
INSERT INTO `blogs` VALUES ('001486355078236c3ff8a25f03e4978bd780c1fcb381a0c000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355078.23681);
INSERT INTO `blogs` VALUES ('00148635508416379f1263c999d4e08b21ce230d6d6802e000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355084.16353);
INSERT INTO `blogs` VALUES ('001486355090591445ca882840248a69be8a2d7b3750e5f000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355090.59155);
INSERT INTO `blogs` VALUES ('0014863550951715ccae566f59645b2b73a5364bc0f668f000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355095.17142);
INSERT INTO `blogs` VALUES ('0014863550999175edde9375db84c07a7ba1583e80b6f2d000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355099.91695);
INSERT INTO `blogs` VALUES ('0014863551043238ccba2c11ab14b40aedf2547a35c2906000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355104.32339);
INSERT INTO `blogs` VALUES ('00148635513603846e5687c75fa4e14ade6e43b43dbf60c000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355136.03793);
INSERT INTO `blogs` VALUES ('00148635514090603303e75501a4b8b98e7e58c2c48cbf9000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355140.90663);
INSERT INTO `blogs` VALUES ('001486355145328933fe48a497a45868852daaabed6e23c000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','Just Have a Try','Just Have a Try','Just Have a Try',1486355145.32785);
INSERT INTO `blogs` VALUES ('00148635531145209b2e9269d6e45b499423487024953bd000','001486352358573637acbf71e364c86bfb36489d692e243000','何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120','？？？','？？？','？？？',1486355311.45233);

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--


--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('001486352358573637acbf71e364c86bfb36489d692e243000','qingxuanshabao@gmail.com','0b7f66fac3ed39d803bc15b7568353ea3718db20',1,'何夕','http://www.gravatar.com/avatar/838f10cced46e0ed6c349fdc6b5295d2?d=mm&s=120',1486352358.57342);
INSERT INTO `users` VALUES ('001486354855330cfa50394bf87417096bc208a289f05aa000','your-name@example.com','5e75f4f522824d62a93c2fe4725484982f1fa5f9',1,'惟科一人','http://www.gravatar.com/avatar/c95fb2bc3c14f9b9432abda6772e1951?d=mm&s=120',1486354855.33067);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-06 23:59:32
