#!/usr/bin/env python3
# -*- coding: utf-8 -*-


__author__ = 'Li Chenxi'
"""
Override configurations.
"""

# config = {
#     'db': {
#         'host': '123.206.182.83',
#     },
# }
config = {}
